"""
Classical baseline: TF-IDF (char n-grams) + Logistic Regression.
Char n-grams work better than word n-grams for code-mixed / mixed-spelling text.
Runs in seconds on CPU — use this to show the transformer's improvement in your report.

Usage:
    python scripts/baseline.py --train data/train.tsv --val data/val.tsv --test data/test.tsv
"""
import argparse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score, f1_score

from preprocess import load_split, ID2LABEL


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", default="data/train.tsv")
    ap.add_argument("--val", default="data/val.tsv")
    ap.add_argument("--test", default="data/test.tsv")
    args = ap.parse_args()

    train_df = load_split(args.train)
    test_df = load_split(args.test)

    vectorizer = TfidfVectorizer(
        analyzer="char_wb", ngram_range=(2, 4), max_features=20000, min_df=2
    )
    X_train = vectorizer.fit_transform(train_df["text_clean"])
    X_test = vectorizer.transform(test_df["text_clean"])

    clf = LogisticRegression(max_iter=1000, class_weight="balanced", C=1.0)
    clf.fit(X_train, train_df["label"])

    preds = clf.predict(X_test)
    y_test = test_df["label"]

    label_names = [ID2LABEL[i] for i in range(len(ID2LABEL))]
    print("=== Baseline: TF-IDF (char n-grams) + Logistic Regression ===")
    print(f"Accuracy: {accuracy_score(y_test, preds):.4f}")
    print(f"Macro F1: {f1_score(y_test, preds, average='macro'):.4f}")
    print()
    print(classification_report(y_test, preds, target_names=label_names, digits=4))


if __name__ == "__main__":
    main()
