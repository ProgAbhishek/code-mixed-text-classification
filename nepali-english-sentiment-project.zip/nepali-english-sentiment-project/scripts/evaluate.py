"""
Evaluate a fine-tuned model on the test set.
Produces: classification report, confusion matrix plot, per-class metrics.

Usage:
    python scripts/evaluate.py --model_dir outputs/xlmr-sentiment/final --test data/test.tsv
"""
import argparse
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix
from transformers import AutoTokenizer, AutoModelForSequenceClassification

from preprocess import load_split, ID2LABEL


def predict_batch(texts, model, tokenizer, device, batch_size=32, max_length=128):
    preds = []
    model.eval()
    with torch.no_grad():
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            enc = tokenizer(batch, truncation=True, padding=True,
                             max_length=max_length, return_tensors="pt").to(device)
            logits = model(**enc).logits
            batch_preds = torch.argmax(logits, dim=1).cpu().numpy()
            preds.extend(batch_preds.tolist())
    return preds


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model_dir", default="outputs/xlmr-sentiment/final")
    ap.add_argument("--test", default="data/test.tsv")
    ap.add_argument("--out_dir", default="outputs")
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")

    test_df = load_split(args.test)
    tokenizer = AutoTokenizer.from_pretrained(args.model_dir)
    model = AutoModelForSequenceClassification.from_pretrained(args.model_dir).to(device)

    texts = test_df["text_clean"].tolist()
    true_labels = test_df["label"].tolist()

    preds = predict_batch(texts, model, tokenizer, device)

    label_names = [ID2LABEL[i] for i in range(len(ID2LABEL))]
    report = classification_report(true_labels, preds, target_names=label_names, digits=4)
    print("\n=== Classification Report ===")
    print(report)

    with open(f"{args.out_dir}/classification_report.txt", "w") as f:
        f.write(report)

    cm = confusion_matrix(true_labels, preds)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=label_names, yticklabels=label_names)
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.title("Confusion Matrix — Test Set")
    plt.tight_layout()
    plt.savefig(f"{args.out_dir}/confusion_matrix.png", dpi=150)
    print(f"\nSaved: {args.out_dir}/classification_report.txt")
    print(f"Saved: {args.out_dir}/confusion_matrix.png")


if __name__ == "__main__":
    main()
