# Nepali-English Code-Mixed Sentiment Classification

One-day project pipeline: preprocessing → XLM-RoBERTa fine-tuning → evaluation → baseline comparison → demo.

## Setup (on your local GPU machine)

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Put your files in `data/`:
```
data/train.tsv
data/val.tsv
data/test.tsv
```
Each must have columns: `id`, `text`, `sentiment` (values: Positive / Negative / Neutral).

## Run order

### 1. Sanity-check preprocessing
```bash
python3 scripts/preprocess.py data/train.tsv
```
Check the cleaned text looks right, and that label distribution matches what you expect.
Add any romanized-Nepali spelling variants you spot to `SPELLING_MAP` in `scripts/preprocess.py`.

### 2. Fine-tune XLM-RoBERTa
```bash
python3 scripts/train.py \
    --train data/train.tsv --val data/val.tsv \
    --model_name xlm-roberta-base \
    --epochs 4 --batch_size 16 --lr 2e-5
```
- Takes ~15-40 min on a single local GPU depending on dataset size (with ~1000 rows/split, expect the low end).
- If you hit CUDA out-of-memory, drop `--batch_size` to 8.
- Saves best checkpoint (by macro-F1) to `outputs/xlmr-sentiment/final`.

### 3. Evaluate on test set
```bash
python3 scripts/evaluate.py \
    --model_dir outputs/xlmr-sentiment/final \
    --test data/test.tsv
```
Produces `outputs/classification_report.txt` and `outputs/confusion_matrix.png` — use both directly in your report.

### 4. Classical baseline (for comparison table in report)
```bash
python3 scripts/baseline.py \
    --train data/train.tsv --val data/val.tsv --test data/test.tsv
```
Runs in seconds on CPU. Put its accuracy/macro-F1 next to the transformer's in a comparison table — this is your "results" section.

### 5. Interactive demo (for your defense)
```bash
python3 scripts/demo.py --model_dir outputs/xlmr-sentiment/final
```

## What to put in your report
1. **Problem**: why code-mixed Nepali-English sentiment is hard (no standard spelling, romanized script, word-level language switching, low-resource).
2. **Data**: size, label distribution, source (mention if it's your own annotated data or an existing corpus).
3. **Preprocessing**: normalization steps in `preprocess.py` — explain why no stemming.
4. **Models**: baseline (TF-IDF + LogReg) vs XLM-RoBERTa fine-tune — one paragraph on why XLM-R (pretrained on 100 languages, includes some Nepali).
5. **Results**: comparison table (accuracy, macro-F1 for both), confusion matrix, 2-3 example predictions (include a failure case — reviewers like seeing you understand the model's limits).
6. **Limitations / future work**: small dataset size, no code-mixing-aware tokenizer, could extend to more classes or add sarcasm detection.

## Notes
- `fp16` is auto-enabled in training if CUDA is available — speeds up training on your GPU.
- If validation macro-F1 doesn't improve past epoch 2-3, that's normal on small datasets — the `load_best_model_at_end` setting keeps the best checkpoint regardless of the final epoch.
